package ch.epfl.cs107.play.window;

/**
 * Context-agnostic immutable sound.
 */
public interface Sound {

    // May be completed here
}
